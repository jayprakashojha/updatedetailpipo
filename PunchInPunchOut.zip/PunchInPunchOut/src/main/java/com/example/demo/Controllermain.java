  package com.example.demo;

import java.awt.Window;
import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import javax.script.ScriptEngine;
import javax.swing.JOptionPane;

import org.apache.catalina.connector.Request;
import org.hibernate.query.criteria.JpaWindow;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import jakarta.servlet.http.HttpSession;


@Controller
@RequestMapping("/")
public class Controllermain {

	
	
	public int s;
	String Username;
    public int count;
    public String punchintime;
    @Autowired
    private Interfacefirst service;
	@Autowired
	private Interface2Implsecond servi;
	@Autowired
	private InterfaceDT1 dts;
	
	
	
	@RequestMapping("/index")
	public String index()
	{
		return "index";
	}
	@RequestMapping("/Registration")
	public String Registration()
	{
		return"Registration";
	}
	
	@RequestMapping("/LogIn1")
	public String LogIn(@RequestParam String username,@RequestParam String pwd)
	{
		Username=username;
		System.out.println("received in services username"+ username);
		System.out.println("received in services password"+pwd);
        String str="select phone,password from updatedetail";
		List<Bean> dataList=servi.findBySqlQuery(str);
		for(int i=0;i<dataList.size();i++)
		{
		Bean b=dataList.get(i);
		String phone =   b.getPhone();
		 String pwd1=    b.getPassword();
		
		 
		 
		if(username.equals(phone) && pwd.equals(pwd1))
		{
			System.out.println(phone);
			System.out.println(pwd1);
				s=0;
				System.out.println(s);
				return "Login";
				
		}
		else
		{ 
			
		s=1;
		}}
		if(s==0)
		{
			return "Login";
		}
		else
		{
					return "index";
		}
	}
	
	@PostMapping("/upload")
	public String uploadFile(@RequestParam String fname,@RequestParam String middle,@RequestParam String last,
			@RequestParam String phone,
			@RequestParam String dob,
			@RequestParam String email,
			@RequestParam String category,
			@RequestParam String spab,
			@RequestParam String kd,
			@RequestParam String state,
			@RequestParam String district,
			@RequestParam String address,
			@RequestParam String city,
			@RequestParam int pincode,
			@RequestParam String documenttype,
			@RequestParam int dn,
	
			
			@RequestParam("document") MultipartFile multipartfile,
			RedirectAttributes ra) throws IOException
	{
		String fileName=StringUtils.cleanPath(multipartfile.getOriginalFilename());
		Product document=new Product();
		document.setFname(fname);
		document.setMiddle(middle);
		document.setLast(last);
		document.setPhone(phone);
		document.setDob(dob);
		document.setEmail(email);
		document.setCategory(category);
		document.setSpab(spab);
		document.setKd(kd);
		document.setState(state);
		document.setDistrict(district);
		document.setAddress(address);
		document.setCity(city);
		System.out.println(city);
		document.setPincode(pincode);
		document.setDocumenttype(documenttype);
		document.setDn(dn);
		String pwd=PasswordGenerate.generateRandomString(10);
		document.setPassword(pwd);
		System.out.println(pwd);
		System.out.println(city);
		document.setPhoto(multipartfile.getBytes());
		document.setPhotoname(fileName);
		
		
		service.save(document);
		
		
		
	
		return "Registration";
	}
	@RequestMapping({"/showAction"})
	public ResponseEntity<?> showaction(ModelMap model)
	{
		
		String str="select id,fname,phone from updatedetail";
		
		List<Bean> dataList=servi.findBySqlQuery(str);
	
		
		//String tableRowStr = "<table id=\"tablename\" class=\"table table-striped table-bordered table-sm\" style=\"width: 30%; font-size: fs;\"><thead><tr><th>ID</th><th>NAME</th><th>Phone</th></tr></thead><tbody id=\"dbDateSendOtpTableBody\">";
		String tableRowStr = "<style>tablename, th, td {\r\n"
				+ "  border: 1px solid black;\r\n"
				+ "border-collapse: collapse;}</style><table id=\"tablename\" class=\"table table-striped table-bordered table-sm\" style=\"width: 30%; font-size: fs;\"><thead><tr><th>ID</th><th>NAME</th><th>Phone</th></tr></thead><tbody id=\"dbDateSendOtpTableBody\">";
		for(int i=0;i<dataList.size();i++)
		{
		Bean b=dataList.get(i);
		count=i;
		
		tableRowStr = tableRowStr + "<tr> <td><a href=getId>" + b.getId() + "</a></td> <td>" + b.getFname() + "</td><td>" + b.getPhone() + "</td></tr>";
		//id1=(b.getId());
		
		
		}
		count++;
		tableRowStr=tableRowStr +"<tr> <td>Total Records:-"+count+"</label></td></tr>";
		 tableRowStr = tableRowStr + "</tbody></table>";
		 
		return ResponseEntity.ok(tableRowStr);
	}
	
	@PostMapping("/punchinout")
	public String punchinout()
	{
		java.util.Date date = Calendar.getInstance().getTime();  
         SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss");  
         String strDatepin = dateFormat.format(date);  
         System.out.println("Converted String: " + strDatepin);  
         punchintime=strDatepin;
		
        
		System.out.println(Username);
		DTEntity d=new DTEntity();
		d.setPhone(Username);
		d.setPunchin(strDatepin);
		dts.save(d);
		
		return"LogIn";
	}
	
	
		
		@PostMapping("/punchout")
		public String updateProduct()
		{
			FetchDataDB pi=new FetchDataDB();
			String punchi=pi.fetchpunchinput();
			 System.out.println("punch in time is"+punchi);
			 
			java.util.Date date = Calendar.getInstance().getTime();  
	         SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss");  
	         String strDate = dateFormat.format(date); 
	         System.out.println(strDate);
	      
	   try
	         {
	         Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student", "root", "12345");
	         System.out.println("Connection established......");
	         //Inserting values to a table

	        // String query = "INSERT INTO punchio1(id,punch_out) VALUES (?,?)";
	         String query="update punchio1 set punch_out='"+strDate+"' where phone='"+Username+"'and punch_in='"+punchi+"'";

	         PreparedStatement pstmt = con.prepareStatement(query);
	        // pstmt.setInt(1, 12);
	        // pstmt.setString(2, strDate);
	        
	         pstmt.execute();
	         System.out.println("Data updated sucessfully......");
	         
	         
	         }
	         catch(Exception e)
	         {
	        	 
	         }
	         return "LogIn";
	      }
	     	
	         
	         
			/*DTEntity existingProduct=ifor.findByPhone(Username);
			existingProduct.setPunchout(strDate);
			
			
			return ifor.save(existingProduct);*/
			
	       /*  Connection con;
			try {
				con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student","root","12345");
				PreparedStatement stmt=con.prepareStatement("update punchio1 set punchout="+strDate+" where phone=9893889778");
				int i=stmt.executeUpdate();  
				System.out.println(i+" records updated");  
			} catch (SQLException e) {
				
				e.printStackTrace();
			}*/
	     	  
	     	 
			
		
	
	@GetMapping("/getId")
	public String getId()
	{
		
		//System.out.println(id1);
	return "getId";	
	}
			
	
}
