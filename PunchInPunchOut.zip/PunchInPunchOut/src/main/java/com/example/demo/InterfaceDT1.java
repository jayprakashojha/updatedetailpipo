package com.example.demo;

import java.util.Date;

import org.springframework.data.jpa.repository.JpaRepository;

public interface InterfaceDT1 extends JpaRepository<DTEntity,Long>{

	

	

	
}
