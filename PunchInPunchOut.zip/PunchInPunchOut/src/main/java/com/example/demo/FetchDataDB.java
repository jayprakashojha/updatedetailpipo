package com.example.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class FetchDataDB {
	    
	public String fetchpunchinput()
	{
	    String empNo = null;	
		Connection con = null;
		{
		try {
			
		con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student", "root", "12345");
		String query="select punch_in from punchio1";
	    PreparedStatement stmt = null;
		stmt = con.prepareStatement(query);
		ResultSet rs = null;
		rs = stmt.executeQuery();
		while (rs.next())
   {               
    empNo = rs.getString(1);           
    System.out.println("Employee number = " + empNo);
				                          
   }
			rs.close();
		    stmt.close();
		} 
		catch (SQLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}                     
	    
	  
	    System.out.println("Data fetch sucessfully......" +empNo);
	    return empNo;
	    }
			
	
		
	
	}
}

