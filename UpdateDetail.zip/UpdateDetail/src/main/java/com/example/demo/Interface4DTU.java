package com.example.demo;

import java.util.List;

public interface Interface4DTU {

	public List<BeanUPD> findBySqlQuery(String command);
}
