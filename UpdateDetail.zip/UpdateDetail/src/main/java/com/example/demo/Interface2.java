package com.example.demo;

import java.util.List;

public interface Interface2 {

	public List<Bean> findBySqlQuery(String command);
}
