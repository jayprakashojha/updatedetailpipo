package com.example.demo;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
@Controller
@RequestMapping("/")
public class Controllermain {

	@Autowired
	private Interface4DTU ifor;
	@Autowired
	private InterfaceDT dts;
	
	public int s;
	String Username;
    public int count;
	@Autowired
	private Interface1 service;
	@Autowired
	private Interface2Impl servi;
	
	@RequestMapping("/index")
	public String index()
	{
		return "index";
	}
	@RequestMapping("/Registration")
	public String Registration()
	{
		return"Registration";
	}
	
	@RequestMapping("/LogIn1")
	public String LogIn(@RequestParam String username,@RequestParam String pwd)
	{
		Username=username;
		System.out.println(username);
		System.out.println(pwd);
        String str="select phone,password from updatedetail";
		List<Bean> dataList=servi.findBySqlQuery(str);
		for(int i=0;i<dataList.size();i++)
		{
		Bean b=dataList.get(i);
		String phone =   b.getPhone();
		 String pwd1=    b.getPassword();
		
		 
		 
		if(username.equals(phone) && pwd.equals(pwd1))
		{
			System.out.println(phone);
			System.out.println(pwd1);
				s=0;
				System.out.println(s);
				return "Login";
				
		}
		else
		{ 
			
		s=1;
		}}
		if(s==0)
		{
			return "Login";
		}
		else
		{
			return "index";
		}
	}
	
	@PostMapping("/upload")
	public String uploadFile(@RequestParam String fname,@RequestParam String middle,@RequestParam String last,
			@RequestParam String phone,
			@RequestParam String dob,
			@RequestParam String email,
			@RequestParam String category,
			@RequestParam String spab,
			@RequestParam String kd,
			@RequestParam String state,
			@RequestParam String district,
			@RequestParam String address,
			@RequestParam String city,
			@RequestParam int pincode,
			@RequestParam String documenttype,
			@RequestParam int dn,
	
			
			@RequestParam("document") MultipartFile multipartfile,
			RedirectAttributes ra) throws IOException
	{
		String fileName=StringUtils.cleanPath(multipartfile.getOriginalFilename());
		Product document=new Product();
		document.setFname(fname);
		document.setMiddle(middle);
		document.setLast(last);
		document.setPhone(phone);
		document.setDob(dob);
		document.setEmail(email);
		document.setCategory(category);
		document.setSpab(spab);
		document.setKd(kd);
		document.setState(state);
		document.setDistrict(district);
		document.setAddress(address);
		document.setCity(city);
		System.out.println(city);
		document.setPincode(pincode);
		document.setDocumenttype(documenttype);
		document.setDn(dn);
		String pwd=PasswordGenerate.generateRandomString(10);
		document.setPassword(pwd);
		System.out.println(pwd);
		System.out.println(city);
		document.setPhoto(multipartfile.getBytes());
		document.setPhotoname(fileName);
		
		
		service.save(document);
		
		
	
		return "index";
	}
	@RequestMapping({"/showAction"})
	public ResponseEntity<?> showaction(ModelMap model)
	{
		
		String str="select id,fname,phone from updatedetail";
		
		List<Bean> dataList=servi.findBySqlQuery(str);
	
		
		//String tableRowStr = "<table id=\"tablename\" class=\"table table-striped table-bordered table-sm\" style=\"width: 30%; font-size: fs;\"><thead><tr><th>ID</th><th>NAME</th><th>Phone</th></tr></thead><tbody id=\"dbDateSendOtpTableBody\">";
		String tableRowStr = "<style>tablename, th, td {\r\n"
				+ "  border: 1px solid black;\r\n"
				+ "border-collapse: collapse;}</style><table id=\"tablename\" class=\"table table-striped table-bordered table-sm\" style=\"width: 30%; font-size: fs;\"><thead><tr><th>ID</th><th>NAME</th><th>Phone</th></tr></thead><tbody id=\"dbDateSendOtpTableBody\">";
		for(int i=0;i<dataList.size();i++)
		{
		Bean b=dataList.get(i);
		count=i;
		
		tableRowStr = tableRowStr + "<tr> <td><a href=getId>" + b.getId() + "</a></td> <td>" + b.getFname() + "</td><td>" + b.getPhone() + "</td></tr>";
		//id1=(b.getId());
		
		
		}
		count++;
		tableRowStr=tableRowStr +"<tr> <td>Total Records:-"+count+"</label></td></tr>";
		 tableRowStr = tableRowStr + "</tbody></table>";
		 
		return ResponseEntity.ok(tableRowStr);
	}
	
	@PostMapping("/punchinout")
	public String punchinout()
	{
		java.util.Date date = Calendar.getInstance().getTime();  
         SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");  
         String strDate = dateFormat.format(date);  
         System.out.println("Converted String: " + strDate);  
		
        
		System.out.println(Username);
		DTEntity d=new DTEntity();
		d.setPhone(Username);
		d.setPunchin(strDate);
		dts.save(d);
		
		return"LogIn";
	}
	
	@PostMapping("/punchout")
	public String punchout(DTEntity dte)
	{
		System.out.println("thisis mobile number"+Username);
		java.util.Date date = Calendar.getInstance().getTime();  
         SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");  
         String strDate = dateFormat.format(date);  
         System.out.println("Converted String: " + strDate);  
         String str="update punchio1 set punch_out='"+strDate+"' where phone="+Username+"";
         ifor.findBySqlQuery(str);
		
         	return"LogIn";
	}
	
	
	@GetMapping("/getId")
	public String getId()
	{
		
		//System.out.println(id1);
	return "getId";	
	}
			
	
}
